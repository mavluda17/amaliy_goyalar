<?php
include 'connection.php';

if (isset($_POST['nomi'])  && isset($_POST['matni']) ) {
    $nomi= $_POST['nomi'];
    $matni= $_POST['matni'];
    $foydasi= $_POST['foydasi'];

    $filename = $_FILES["rasmi"]["name"];
    $tempname = $_FILES["rasmi"]["tmp_name"];
    $folder = "rasm/" . $filename;

    if(move_uploaded_file($tempname,$folder)){
        echo "rasm yuklandi!";
    }
    else echo "rasm yuklashda xatolik";

    $id = intval($_POST['id']);

    $sql = "UPDATE idea SET  nomi='$nomi', matni = '$matni', foydasi='$foydasi' , rasmi='$filename' WHERE id = '$id' ";
    if ($connection->query($sql)) {
        header('Location:idea.php');
    } else echo 'xato!' . $connection->error;
}
$connection->close();
