<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Sadullayeva Mavluda</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <style>
        .box_main {
            width: 300px;
            height: 400px;
        }
        
        .box_main image {
            width: 200px;
            height: 300px;
        }
        
        .images {
            width: 250px;
            height: 300px;
        }
    </style>
</head>

<body>
    <!--header section start -->
    <div class="header_section">
        <div class="header_left">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                            <a class="nav-link" href="index.php">Asosiy</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">Haqida</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.php">G'oyalar</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="contact.html">Biz bilan bog`lanish</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!--header section end -->
        <!--team section start -->
        <div class="team_section layout_padding">
            <div class="container">
                <div class="container">
                    <h1 class="what_taital">Bizdagi g`oyalar</h1>
                    <p class="what_text">Bizning g`oyalarimiz haqida </p>
                    <div class="what_we_do_section_2">
                        <div class="row">

                            <?php
    include 'connection.php';
    $sql = "SELECT * FROM idea";
    $result = $connection->query($sql);
    if($result->num_rows>0) {
        while($row = $result->fetch_assoc()) {
            ?>

                                <div class="col-lg-4 col-sm-6">
                                    <div class="box_main">
                                        <div class="icon_1"><img src="rasm/<?php echo $row['rasmi']?>"></div>
                                        <h3 class="accounting_text"><small></small>G'oya nomi: </smal>
                                            <?php echo $row['nomi']?>
                                        </h3>
                                        <p class="lorem_text"><small>G'oya matni: </small>
                                            <?php echo $row['matni']?>
                                        </p>
                                        <div class="moremore_bt_1"><small>G'oya foydasi: </small>
                                            <?php echo $row['foydasi']?>
                                        </div>
                                    </div>
                                </div>
                                <?php
        }
    }
    ?>
                        </div>
                    </div>
                </div>
            </div>
            <!--team section end -->
            <!--footer section start -->
            <div class="footer_section layout_padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <h4 class="about_text">Amaliy g'oyalar</h4>
                        <div class="location_text"><img src="images/map-icon.png"><span class="padding_left_15">Joylashuv</span></div>
                        <div class="location_text"><img src="images/call-icon.png"><span class="padding_left_15">97_737_88_58</span></div>
                        <div class="location_text"><img src="images/mail-icon.png"><span class="padding_left_15">Mavluda@gmail.com</span></div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <h4 class="about_text">G`oyalarimiz haqida</h4>
                        <p class="dolor_text">Bizning xizmatimiz sizga g`oya yaratish va uni bo`lishishni o`rgatadi.</p>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <h4 class="about_text">Instagram</h4>
                        <div class="footer_images">
                            <div class="footer_images_left">
                                <div class="image_12"><img src="images/img-12.png"></div>
                                <div class="image_12"><img src="images/img-12.png"></div>
                                <div class="image_12"><img src="images/img-12.png"></div>
                            </div>
                            <div class="footer_images_right">
                                <div class="image_12"><img src="images/img-12.png"></div>
                                <div class="image_12"><img src="images/img-12.png"></div>
                                <div class="image_12"><img src="images/img-12.png"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <h4 class="about_text">Axborot byulletenti</h4>
                        <input type="text" class="mail_text" placeholder="Emailingizni kiriting" name="Enter your email">
                        <div class="subscribe_bt"><a href="#">OBUNA BO`LING</a></div>
                        <div class="footer_social_icon">
                            <ul>
                                <li>
                                    <a href="#"><img src="images/fb-icon1.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/twitter-icon1.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/linkedin-icon1.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/youtub-icon1.png"></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- copyright section start -->
                <div class="copyright_section">
                    <div class="copyright_text">
                        <a href="https://html.design"></a>
                    </div>
                </div>
                <!-- copyright section end -->
            </div>
        </div>
        <!--footer section end -->
        <!-- Javascript files-->
        <script src="js/jquery.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/jquery-3.0.0.min.js"></script>
        <script src="js/plugin.js"></script>
        <!-- sidebar -->
        <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
        <script src="js/custom.js"></script>
        <!-- javascript -->
        <script src="js/owl.carousel.js"></script>
        <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>

</html>
<a href="#"><img src="images/fb-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/twitter-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/linkedin-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/youtub-icon1.png"></a>
</li>
</ul>
</div>
</div>
</div>
<!-- copyright section start -->
<div class="copyright_section">
    <div class="copyright_text">
        <a href="https://html.design"></a>
    </div>
</div>
<!-- copyright section end -->
</div>
</div>
<!--footer section end -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>

</html>la
<a href="#"><img src="images/fb-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/twitter-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/linkedin-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/youtub-icon1.png"></a>
</li>
</ul>
</div>
</div>
</div>
<!-- copyright section start -->
<div class="copyright_section">
    <div class="copyright_text">
        <a href="https://html.design"></a>
    </div>
</div>
<!-- copyright section end -->
</div>
</div>
<!--footer section end -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>

</body>

</html>
</body>

</html>

</html>