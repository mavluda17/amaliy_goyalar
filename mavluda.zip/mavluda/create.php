<?php
//error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'connection.php';
if (isset($_POST['saqlash'])) {
    $email = $_POST['email'];
    $nomi = $_POST['nomi'];
    $maqsadi =$_POST['maqsadi'];
    $matni =$_POST['matni'];
    //rasm uchun
    $filename = $_FILES["rasmi"]["name"];
    $tempname = $_FILES["rasmi"]["tmp_name"];
    $folder = "rasm/" . $filename;
    if(move_uploaded_file($tempname,$folder)){
        echo "rasm yuklandi!";
    }
    else echo "rasm yuklashda xatolik";
    $sql = "INSERT INTO `goya` (`email`, `nomi`, `maqsadi`, `matni`,`rasmi`) VALUES ('".addslashes($email)."', '".addslashes($nomi)."','".addslashes($maqsadi)."', '".addslashes($matni)."','".addslashes($filename)."' )";

    if ($connection->query($sql)) {
        ?>
        <script !src="">alert('Saqlandi')</script>
      <?php
    } else echo 'xato!' . $connection->error;
  
}

?>



