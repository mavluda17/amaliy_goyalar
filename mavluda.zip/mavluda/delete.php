<?php
include 'connection.php';
$id = $_POST['id'];
$sql = "DELETE FROM goya where id='$id'";
if ($connection->query($sql) === TRUE) {
    header("Location:xabar.php");
} else echo $connection->error;
