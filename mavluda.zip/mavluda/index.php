<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Sadullayeva Mavluda</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
<style>
    .box_main{
        width: 300px;
        height: 400px;
    }
    .box_main image{
        width: 200px;
        height: 300px;
    }

    .images{
        width: 250px;
        height: 300px;
    }
</style>
</head>

<body>
    <!--header section start -->
    <div class="header_section">
        <div class="header_left">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Asosiy</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">Haqida</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.php">G'oyalar</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="contact.html">Biz bilan bog`lanish</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="banner_main">
                <h1 class="banner_taital">Amaliy g'oyalar</h1>
                <p class="banner_text">Biz bilan yangi g`oya yarating va ulashing<br>
                    <br>Bizda faqat manfatli takliflar foydali ma 'lumotlar bo'lai
                    <br>
                    <br> Yangi g'oya va takliflaringgizni bi bilan ulashing
                    <br>
                    <br> Sizning fikringgiz biz uchun muhim</p>
            </div>
        </div>
        <div class="header_right">
            <img src="images/banner-img.png" class="banner_img">
        </div>
    </div>
    <!--header section end -->
    <!--about section start -->
    <div class="services_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h1 class="services_taital">Xizmatimizga hush kelibsiz</h1>
                    <p class="services_text">Biz bilan o`z g`oyalaringizni yaratishni o`rganasiz va yaratgan g`oyalaringizni ko`plab hamkorlar bilan bo`lishishingiz mumkin.BU sizga o`z biznesingizni rivojlantirishga yordam beradi. </p>

                </div>
                <div class="col-md-4">
                    <div><img src="images/img-1.png" class="image_1"></div>
                </div>
            </div>
        </div>
    </div>
    <!--about section end -->
    <!--services section start -->
    <div class="what_we_do_section layout_padding">
        <div class="container">
            <h1 class="what_taital">Bizdagi g`oyalar</h1>
            <p class="what_text">Bizning g`oyalarimiz haqida </p>
            <div class="what_we_do_section_2">
                <div class="row">

<?php
include 'connection.php';
$sql = "SELECT * FROM idea";
$result = $connection->query($sql);
if($result->num_rows>0) {
    while($row = $result->fetch_assoc()) {
        ?>

                    <div class="col-lg-4 col-sm-6">
                        <div class="box_main">
                            <div class="icon_1"><img src="rasm/<?php echo $row['rasmi']?>"></div>
                            <h3 class="accounting_text"><small></small>G'oya nomi: </smal><?php echo $row['nomi']?></h3>
                            <p class="lorem_text"><small>G'oya matni: </small><?php echo $row['matni']?></p>
                            <div class="moremore_bt_1"><small>G'oya foydasi: </small><?php echo $row['foydasi']?></div>
                        </div>
                    </div>
                <?php
    }
}
?> 
                </div>
            </div>
        </div>
    </div>
    <!--services section end -->
    <!--project section start -->

    <br>
    <div class="project_section_2 layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="icon_1"><img src="images/icon-3.png"></div>
                    <h3 class="accounting_text_1">1000+</h3>
                    <p class="yers_text">Kuzatuvchilar</p>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="icon_1"><img src="images/icon-4.png"></div>
                    <h3 class="accounting_text_1">20000+</h3>
                    <p class="yers_text">Fikrildirganlar</p>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="icon_1"><img src="images/icon-2.png"></div>
                    <h3 class="accounting_text_1">100+</h3>
                    <p class="yers_text">Foydali g'oya egalari</p>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="icon_1"><img src="images/icon-1.png"></div>
                    <h3 class="accounting_text_1">1500+</h3>
                    <p class="yers_text">Foydalanganlr</p>
                </div>
            </div>
        </div>
    </div>
    <!--project section end -->
    <!--team section start -->
    <div class="team_section layout_padding">
        <div class="container">
            <h1 class="what_taital">Muttaxasislarimiz</h1>
            <p class="what_text_1">Bizga kelgan xabarlarni exspertlar ruxsati bilan saytga joylanadi</p>
            <div class="team_section_2 layout_padding">
                <div class="row">
                    <div class="col-sm-4">
<img style="width: 500px; height: 400px;" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBISEhgREhESGBgYGBgSGhkYERgYGBgYGhkaGhgZGBgcIy4lHB4rIRoYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHDYrJSw0NDQ0MTQ0NDQ2NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQxNDQ0NDQ0NDQ0NDQ0NDE0NP/AABEIAKsBJgMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAAAQIEBQYDB//EAD4QAAIBAgQDBQYDBwQCAwEAAAECAAMRBBIhMQVBUSJhcYGRBhMyobHBQtHwFCNSYnKC4TOSssKi8SRDYxb/xAAYAQEAAwEAAAAAAAAAAAAAAAAAAQIDBP/EACIRAQEAAgEEAgMBAAAAAAAAAAABAhEhAxIxQSIyQlFxkf/aAAwDAQACEQMRAD8A6gSQiEksosYkhEJISAxHEJKAQEI4BHARwCOEcgEcIQCOEIBHCEAhCeGOxS0qbVG2A9TyEE5VOMcZp4ZRm1c/Cg3Pj0E4vFY6vjHCm5W+iLoo8evjPLEM2Iqs76s2u9lC8h6Td4NRRGsouRp016C0zyy06+n05jN+3uOHYTB0g9ZAXtsXzX7rHQzOFZajXCKq8gGC2HmQZH2kd6lRc21tFGg9d7d5/OSwuVCM1WmijTLlufXlM/W60mO3X8Ew4sCoHk1x6XM08dTBXWZnB3RgCjK/erKSPTX1mninzDTWUlZ5fZkPSydpCAf/ABPd3S1RrBhtYjcdJ5FwdPK3Xu/zPNFykEG/Q9RzU94mmGWlM8dxdhBTcXhN3OUI4oBFHCAoo4QIwjhAoiSEiJISQxJCIRiBIRxCMQHGIo4DEcQjgOEI5AI4o4BHCEAhCEAnL+1mIuRTPwqMx8Z1BM4j2hqZnPj9JXKtejN5MujUCgtcjm3nsvlLOAx7ioMtrmwH8o8+ZlHFL8NPkB7x+8nWx/LvljCU8lv42t5Dn5/nMsvDuxjp8bhf2hVRSFscxO5J6TPHs49Rj2uyO6bfCqJKgTosPhwBaUlqmV7Xz6v7OvS7aM2YbEaEeBlnhftBUpuKWJJ1OUMefS/fO/bDKRqBOX9pOAq6Egd8t/UTKZcVaxS37a77m3PvEjSe9x/ePuPr6TP4JimeiA57aE02vubbH0sZZVsrA9D9f0JXWlLNcNDDPfT08J7Sgz5HBGx+lz+vKX50YXccueOqUI4SypRRwgKKOEBQhCBQEkJESYkhiSEiJIQJCAgICA5KRkoDjiEcgEcUcBwhCA4QhAcIQgV8fUyUyZw+N7VQDmTl8gdf+3rOt4y+gUc5yObNigvJKZc+JOn/ABHrM8ry6OjNTalTT3lQ/wAz5fIaf9Je4eA9QnvNvC9h8gJ4cNS1QeDufEox/wC0r8LxqrUY6kBsoABJOXSwA8JXW3XjdPovDFsBN2nOHwntStP/AFMLiFX+IppOh4X7Q4fEaU316EWMjtsYZ7rcBnjiqWZSImq21vOcx/tFVN1o0xa9i7myjv741tXHG+lOtQNKo9hoQKlupT4h5rpGr9q3I6X7xqD5gyhTd3qrUfH03IN8iAZSCNt/tLr0cpUDY9keWqfK6+QizTSrlU5lBHh58vpNDDVMyA+Uy9SpA5i4/qGvz2nrw3Ej+0/IxhdVj1MdxqyMlCbudGKOEBRRwgKEIQKAkhIiSEkMSQkRJCBIQEBCAxHFHAkIQEJAccUcBwijgOEUcAjiJtOZxPHnZytOwS1gchJ6Xv1kW6WxxuXguK45S7vfROwPHX/Mw8KrAPVYdqpZV/pF7W8b/MTX/Y1NMHKWtrbqepnhUw7lgSNth3zG5OzDHUU3PukqVT+BGHiTpYeQM5vAV6lGkKqIWOxNue5M1Pa/iC0kTDjXMTnN9L20Bl32RCPTVHXW+oPI85pjxj3Vac7ZvCeJ4+vlcspRiy5VIDLYaEhuvjy8p2GGWogQunaKq9wNrgEqTYWI8ps4TgVK4dQB/aL+suYuiqrYCMssb4jOWy+dmCXoB+ZsJzvGuD1KyOjEjbLlZdTcE3Hhfz+fT4UfuAOhlqiFI1sZnLqot1t8jxfsSxa6XVs+bPnPwWACqpJ53N/DWdbg7qPcO2tuyTzI1HnznVVqSDUAek4/2n7C+8BsVZSD0uQPvJyzuVkq+GMs00r2tcWucp7m/wA8vKRo4RlYsBcE3ItPLB44Og94oNxZtLg+I5za4bkAOVwV6E3I8zqfOUimcsitTxFiFa+ugP2MtXlOtiQz5UGt7ZstvG0uCbY21z5yRKRkpGXUEUcUAhCEDPEkJASQkiQkhIxiBIRxRwHHFCBKOREcBxxQkBxxQgMRxQgRrC6kX3BE4Vqy0jaoAxBtfKmvnbwnaY+nUamy02AY7E7d97az57xrCVKdT3b6kspvvcMLEjzErlNt+jdOpwXGaRp2sR5L9jMnFcReo+SkpUZSzN+K2ygdL/aeeDog2RFvYZdt2tsPCa74RaSM515n+Y7Ko+nfczC6ldM1HB+2OCJRDqSBf9epnp7G8RZrht1IUnqLaE/P0mvx1P3dO+pARW/uCBvk05Dgr/suLNNjozGmemYHs/O485tje7GxF+OUv+vuHC8cMkrcVxdt72Onh0mdwdttZn4rilT370KtNUXUo7PdWABJJNrIdNj1meONt4TcZMnWYLilP3R38LT0psXTOAVttymXw/hlQjMqqRcDMapygkA3sB3x8TesEK066F9gEHYU3scx123tbX5y3bUfG3Uq4+MYCxmBxv8AeU2B7h8xNfBYV6dFUqVHqNa5dgLknfYWteZmPILBB/UfLaZ3ir469K+EqhLq2wNr9PGbuDcZdGE5+13dba30v9PQy3wjhzq+rMqkbZte61xEm2efEXURjUAuN76HkJsytTwqKbi5PeZ7zfHHUced3UpGSkZZUQhCAoQhAzhJCREckTEYkRJCBKMSIjgOOKEBiORjgSvCRvC8CV47yN4SBK8d5C8cB3mLx1KdWybuNiPw+MucWxy0aZcmxPZHiZgYbHra9mF+i5mPftKZ5a8Nulhv5Oi4Pw6nSp3Ntjck69TrKGKDVmzlCtJPhBFi56gHZe8+OgAvb4SUY3OYn/8ATN9NVHpIcSdXzXrAKN8mvkX+2k59t59nJY9TVqqp2z526BV1ZvDYDuF58/4u2eqzjmz25G5YkHxsR6TtuL8UVm/Z8OhCvdXqHcjmq9B3+XOcxjsJcEfiV1B+x9NPKb9O68tMse6Oo9kPaQPalUNnHPk46jv6idjjsEtdQ67jnPjZw5F8ujIA466f4+k772Z9oGVFLksp0PURlNcxOMy9eXT4DDlFye5psb7hbX8VtvNPDYJ2YO/gAFyqB3CQwnG6VswIhjePray790pckXut8I8YxYSyje4UeJNhOc/aAMYKZO6Xv1YG5+V56O7O4d/4lPzFpg452XELWH4XPzsR9CJWcr9mo6fEUVzgk5T15G33mriBamM1vG9pVR6dQKbEggMPD8xqPKS4gEVQFYEcwX+xlWV54r2wGKu2Qm99jz8DNGc9wmkDU00y67/IToZ0YW65cvVxky4EIQl2QhCEBQhCBnCMSIjEsJCSEiJKQJRyMcBxyMIEoRQvAd4AxRwCF4XheQHeO8jeEDI9o8J7yna5BHaHQWBLX8pymApI75DXqAjWwQgAfzan5zvq9MOpU7EEeosfkZynE8IyMFK6kZLgaOARa4623+8plHR0cvxXuHvRQ3D1HA56BP8Adck+V551cUca706dwidktrcnoOdgPXTSWqGEFOmFcXdxYDfKPCXeHpTwtMhFAzEkk6sxmFsjf3uOfqcDNyEp2Aso8Bv43mfjeGUqVy7AMSWtbM5/tG3naa3EuKVncpTbKqi7MbAKNN+p12HcOcyTwfEVSahPu6Vrhmuufn8IGvnJx37rTusYeNoJTyV0QshORid011QgbXHO53l7BYUU6pQao3bXwP6+c9kw60swBR0fsOoB7S62I/mB1B8Z5pUC1ES+YAEK3VDYofSX7tr4y7btCnaXKdO8VBNLy3SSY2r2vHErZTbppMfFUA9NmT/7BmUnk4Gi/X1nQYmkWFhz09Z54zChQ2QbJlCnVSfhW67HYycUSsbgvETT7FRWtyNtQdiLePKWsaj4g6MxU7BVt6H/ADIClVspYU9dSQlz0AGa/drOqwlIIu2oEtbzuKZYycszh1FaJuyhWsFAAvYDw1J175sJiUYXBOm5ytYedp4YNWYsW2Btbqefl+ctmiW38gNAPASZnY58+ljbyS1lP4h9PrJzy/YwSdNB9YlRk21HT8pedT9ssuj+q9ooI4YXH67oTRz3gQhCSMwSQnnJiWExHIgx3kAd8vInyNh3seUEqK2z0z4Nf7Stj6d6blVYvkYKUIV7kaZWO2sx8BgVRR/8GszDUtUrISSdySXlbv026cws+TqFpg/jX1k1wrdV9Zg1K+Ipm1PCBxvo6JbusTPP/wDpalPWvgqiC+4GZR/ctxI+S3ZhfDddCpsQYFCOUo4X2nwdTTMv++X6HEsIxsKi+FxI3lEXpT9VC8A19pqKlFtmEZ4ev4WEnuqvZPdZkV5othGH/qUsRTyna0TLaMsNcxC8LyN4XllEalQLKSP7xrhbgHe3MdDt5yfEj2LDckc7WHM38Jn4jitOmhAcdkbIL8upsJjnb4jbp4+0sRVY1AlwMx111sOQ6DaehGZ9Sd7f2gi48T9pk8LRnqe8N8x7QubmwI38e6dHXRQwI2OZv/E6esxymuHTHNcTxWRWNNQBmzk2F73+I9TvYcrHrMTHU1qU0fFl7t2cxu3PmOl50dfBarRFyzEX7lHWT4rwv3iCko+AZr258hLTLWl+PDF4TTpioKFnYagM1htuAN9pa4rwX3bLUprsepNlO5A8h85rYbhw/d3+NCKjHoSLW8TczWCBsyEbXI+4kd3Ozu1WdgxdR4S0q2kkw+XQbT0qLpIaWp0Vuw7gW+w/XdJNQzOy/wAqn0LX+sngEOXN/EfkNvv6yyKVnB7iD8pLO5aqjSwodx0XW3fsJdxJylVH4jb6ywlMLsJUqHNXUfwqW89h/wAj6SVd7q3RphQAP1zJ9TJprc+QkajaWG509Z6otoVpbTyrDTvk1a5Py/MwqiwhHhmYBLFySSzPmJP9IAt0GkuSphT+8f8At/7S1OjHw5Or9qIQhLKMuSEiIxLCQMd5GO8CV47yN4XkCV4XkbwvA862Fpv8dOm1/wCJFP1EwMZ7H0WJai9SkegOdP8AadfQzo7wvJ2tMrPDkBgeI4XVCKqj+Bu1bvRrHyF5dwHtg4b3dVWRuYYFSPEHWdFeV8bgqVZclWmrjvGo8DuPKVslXnVv5Ro4HjAqDRh6y7VXOJweE4bUwdcZajPRe+XN8SNvlY8xvY91j39pwvEiotr90yymq11LNxVdbEg8orz3xyWN/I/aVgZpjdxz5Y9tYPGqLgu7ZmVlstjoG0Fj89e+czTd7jMhBJ5g2+k6b2ycjDWHN0HlqftOSoFg6re+Yi2p3IkXF09Pdx27D2dU1Kjt+FVAHib3J9B8ptpRUEu1yF2HU/nMvBqMLQC8z22Pfpp9B6yzhaj1BmuFUXJYmwAG58fp4zny8rH75aZZ2y5ibAZgMzW0VSdLTLX2mNOoKVekaWbY5S1yeZfmveBp3SzjUWoGRArAWUg767b+O5mlwzAUKFLK5vY3u5vr3ZtvKRNa5Wv7e+FoaZhrftA3+ffAIA179Z50OI0w3uw1r3ybWvzAI08p6kam0gxl3yZTWQelfQbnSe1PaetJbtfp9T+vnJi9uk6SAAAbAWkh8UkIIJKiRlGgP3rt0VV+p+hEuE6/r9f+54URo7fxMfl2R9ITPFeyat4D5n9GetVrKSOQJ+U88PsW6n/ElW2t4fWFaWFSwtz5nrDE6CToTyxraQjzWdhT238B9TLkzsE37xv6fof8zQnRh9XP1p8qcIoSzJlAyQMgDHLCUlI3gDAneF5CO8CV4XkbwvIErwvI3ivAneF5C8LwI4mkKiFDz2PQjUHyNjM72b4gRVam2hB1HQ3sR6zSvOVx7mhxFW2Wqob+4dlvop85XLHcb9HLntvt9ExKBluOcyRobTRwdYOniJUxiFTfymeN1U547n8c37YMBSQEaGov/FpU4Xg0GSoQbswSmD49pvKXfaakai0kXdqyKO64bWJHHvUYfCGVKf8AQp3895fPiJ6V+Olnimrqp2sGI8P8zP41UqVKJSm1uS2+G/IfX0lnjIYYnN+HIBbqSdfSeVVCEOUBkblzU93nbwM5/DbGTTywyfvkrMln/ZaQbvY3BHlb5z0wuNqVqhIUGmrGmVYaFQbOe4ne/UT14gDTdXyuwVRTNtbKLXOXroDbutFwaiiVC1CorI7ZyubtKTuLb+si3fK8x4RxPDhTqB/eAAMGAvbY6HXedLhLsA3WQxrUyo0APPTSeuBGn36+Ers3uPTLYkSxRWy+Os86663k0fSWit8JmSkBvJVTpbrpJQ8w2l/Fvy+0g4y0wPAT0IiqLdkHfm9P82ge6LYAdBI1Tt4xyFQ7eMI9vVDKuMaWl2lLFNJTPKhg/wDVP9J+omjMzBn96f6D9VmlN8Pq5ev9zhFCWZMgGO8hGJYel4AyIhAneF5EQgSvC8iYoErwvIwgSvC8jCQHecx7bJZKVcfgfKfBx+ar6zppi+1qg4OrpsFPmGXWJ5WwuspWx7PYvPTU35TarqGWcV7GOfdjWdom058pq6dmXly/HH92aTt+Gsl/CxufSVMYPd1Et8I0Hha2nkJa9tf9C/8AMn1lSic2GpsdTcrfutt8pfK7kRjjJwse0WKyqtVd7ZPAkix+ZPkJP2SoPUBqOtkBsg1OfbVr72PPx775mPN6QvrbLO4wiBaSqosBZbDpbaZ3iJy4mnjWpjNfqL+U834dTf4kU9+USTf6p/pEspM2mNsxiknD0QghF07tpeoyQgm8kt2nW1niHsJ7P+Uq1Nm8DCvpdTQRMbxJsI5KEliA7RPQW+5+0kIk+5+sCRnlU3Hn9p6GeT/EPP7SURappcfEL9Ocr4vBPlckrZe+5Oh5ctuc9l0EysViHUFlYgnW4POxlpq+lflvy9MNw3LUY+9UnK2mUg9llVjryvp32PSXjgmB7TIBcC977gm9uW1tZjYHGVHZkZ2K5RoTpvLyVmve51379DN8ZNcObq77uXpWTLazXvrtaEi9Qk6kwkqP/9k=" class="image_7">

                    <p class="readable_text">Sadullayeva Mavluda</p>
                        <p class="readable_text_1">Drektr</p>
                        <div class="social_icon">
                            <ul>
                                <li>
                                    <a href="#"><img src="images/fb-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/twitter-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/linkedin-icon.png"></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4">
   <img style="width: 500px; height: 400px;" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSS_k0F8fEmtr1MGRMF0zuKPlQbKKFg6Yib4Q&usqp=CAU" class="image_7">


                        <p class="readable_text">Niyozmatova Baxtigul</p>
                        <p class="readable_text_1">Ilmiy hodim</p>
                        <div class="social_icon">
                            <ul>
                                <li>
                                    <a href="#"><img src="images/fb-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/twitter-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/linkedin-icon.png"></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <img style="width: 500px; height: 400px;" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZHLM7V8x3h4tIiqXflYdAaRxCngAj5tDlh4jKWHF-DQ_W0om8oA8hs3X_K-YEBdGPTCw&usqp=CAU" class="image_7">
                        <p class="readable_text">Quronbayeva Sarvinoz</p>
                        <p class="readable_text_1">Ishboshqaruvchi</p>
                        <div class="social_icon">
                            <ul>
                                <li>
                                    <a href="#"><img src="images/fb-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/twitter-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/linkedin-icon.png"></a>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--team section end -->
    <!--client section start -->
    <div class="client_section layout_padding">
        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <h1 class="what_taital">Yordamchi dmini</h1>
                        <div class="client_section_2 layout_padding">
                            <ul>
                                <li><img src="images/round-1.png" class="round_1"></li>
                                <li><img src="images/img-11.png" class="image_11"></li>
                                <li><img src="images/round-2.png" class="round_2"></li>
                            </ul>
                            <p class="dummy_text">Saytga yuborilgan g'oyalarni utaxasislar bilan bo'lishadi</p>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <h1 class="what_taital">Admin</h1>
                        <div class="client_section_2 layout_padding">
                            <ul>
                                <li><img src="images/round-1.png" class="round_1"></li>
                                <li><img src="images/img-11.png" class="image_11"></li>
                                <li><img src="images/round-2.png" class="round_2"></li>
                            </ul>
                            <p class="dummy_text">Mutaxasislar to'g'ri deb topilgan fikrlar g'oya sifatida saytga yuklaydi</p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--client section end -->
    <!--footer section start -->
    <div class="footer_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <h4 class="about_text">About Financial</h4>
                    <div class="location_text"><img src="images/map-icon.png"><span class="padding_left_15">Joylashuv</span></div>
                    <div class="location_text"><img src="images/call-icon.png"><span class="padding_left_15">97_737_88_58</span></div>
                    <div class="location_text"><img src="images/mail-icon.png"><span class="padding_left_15">Mavluda@gmail.com</span></div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <h4 class="about_text">G`oyalarimiz haqida</h4>
                    <p class="dolor_text">Bizning xizmatimiz sizga g`oya yaratish va uni bo`lishishni o`rgatadi.</p>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <h4 class="about_text">Instagram</h4>
                    <div class="footer_images">
                        <div class="footer_images_left">
                            <div class="image_12"><img src="images/img-12.png"></div>
                            <div class="image_12"><img src="images/img-12.png"></div>
                            <div class="image_12"><img src="images/img-12.png"></div>
                        </div>
                        <div class="footer_images_right">
                            <div class="image_12"><img src="images/img-12.png"></div>
                            <div class="image_12"><img src="images/img-12.png"></div>
                            <div class="image_12"><img src="images/img-12.png"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <h4 class="about_text">Axborot byulletenti</h4>
                    <input type="text" class="mail_text" placeholder="Emailingizni kiriting" name="Enter your email">
                    <div class="subscribe_bt"><a href="#">OBUNA BO`LING</a></div>
                    <div class="footer_social_icon">
                        <ul>
                            <li>
                                <a href="#"><img src="images/fb-icon1.png"></a>
                            </li>
                            <li>
                                <a href="#"><img src="images/twitter-icon1.png"></a>
                            </li>
                            <li>
                                <a href="#"><img src="images/linkedin-icon1.png"></a>
                            </li>
                            <li>
                                <a href="#"><img src="images/youtub-icon1.png"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- copyright section start -->
            <div class="copyright_section">
                <div class="copyright_text">
                    <a href="https://html.design"></a>
                </div>
            </div>
            <!-- copyright section end -->
        </div>
    </div>
    <!--footer section end -->
    <!-- Javascript files-->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery-3.0.0.min.js"></script>
    <script src="js/plugin.js"></script>
    <!-- sidebar -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- javascript -->
    <script src="js/owl.carousel.js"></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>

</html>
<a href="#"><img src="images/fb-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/twitter-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/linkedin-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/youtub-icon1.png"></a>
</li>
</ul>
</div>
</div>
</div>
<!-- copyright section start -->
<div class="copyright_section">
    <div class="copyright_text">
        <a href="https://html.design"></a>
    </div>
</div>
<!-- copyright section end -->
</div>
</div>
<!--footer section end -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>

</html>la
<a href="#"><img src="images/fb-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/twitter-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/linkedin-icon1.png"></a>
</li>
<li>
    <a href="#"><img src="images/youtub-icon1.png"></a>
</li>
</ul>
</div>
</div>
</div>
<!-- copyright section start -->
<div class="copyright_section">
    <div class="copyright_text">
        <a href="https://html.design"></a>
    </div>
</div>
<!-- copyright section end -->
</div>
</div>
<!--footer section end -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>

</body>

</html>
</body>

</html>

</html>